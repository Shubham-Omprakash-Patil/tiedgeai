# import tensorrt as trt
# import os
# import onnx
# import torch
# import common
# import cv2
# import numpy as np

# from tv.edgeailite import xnn
# from tv.edgeailite import xvision

# args = xnn.utils.ConfigNode()
# args.model_config = xnn.utils.ConfigNode()
# args.model_config.output_type = ['segmentation']   # the network is used to predict flow or depth or sceneflow
# args.model_config.output_channels = [19]            # number of output channels
# args.model_config.prediction_channels = None        # intermediate number of channels before final output_channels
# args.model_config.input_channels = (3,)             # number of input channels
# args.model_config.final_upsample = True             # use final upsample to input resolution or not
# args.model_config.output_range = None               # max range of output
# args.model_config.num_decoders = None               # number of decoders to use. [options: 0, 1, None]
# args.model_config.freeze_encoder = False            # do not update encoder weights
# args.model_config.freeze_decoder = False            # do not update decoder weights
# args.model_config.multi_task_type = 'learned'       # find out loss multiplier by learning, choices=[None, 'learned', 'uncertainty', 'grad_norm', 'dwa_grad_norm']
# args.model_config.target_input_ratio = 1            # Keep target size same as input size
# args.model_config.input_nv12 = False                # convert input to nv12 format
# args.model_config.enable_fp16 = False   
# args.model = None                                   # the model itself can be given from ouside
# args.model_name = 'fpn_aspp_regnetx800mf_edgeailite'# model architecture, overwritten if pretrained is specified
# args.dataset_name = 'cityscapes_segmentation' 

# model_file = 'data/checkpoints/edgeailite/cityscapes_segmentation/2022-08-16_09-02-12_cityscapes_segmentation_fpn_aspp_regnetx800mf_edgeailite_resize768x384_traincrop768x384/training/model_best.pth'
# model, changed_names = xvision.models.pixel2pixel.__dict__[args.model_name](args.model_config, model_file)
# model = model.eval().cuda()

# img_path = '/data/cityscape/leftImg8bit/val/frankfurt/frankfurt_000000_000294_leftImg8bit.png'
# img = cv2.imread(img_path)[:,:,::-1]
# img = cv2.resize(img, (768,384))

# img_mean = 128.0
# img_scale = 1.0/(0.25*256)

# x = (img - img_mean) * img_scale
# x = np.transpose(x, (2, 0, 1))
# x = x[np.newaxis, ...]
# x = torch.from_numpy(x).float().cuda()

# y = model([x])
# print(torch.unique(y[0]))

# output = y[0].cpu().numpy().astype(np.uint8)
# output = output.reshape(384,768) * 10

import tensorrt as trt
import os
import onnx
import torch
import common
import cv2
import numpy as np

from tv.edgeailite import xnn
from tv.edgeailite import xvision

args = xnn.utils.ConfigNode()
args.model_config = xnn.utils.ConfigNode()
args.model_config.output_type = ['segmentation']   # the network is used to predict flow or depth or sceneflow
args.model_config.output_channels = [28]            # number of output channels
args.model_config.prediction_channels = None        # intermediate number of channels before final output_channels
args.model_config.input_channels = (3,)             # number of input channels
args.model_config.final_upsample = True             # use final upsample to input resolution or not
args.model_config.output_range = None               # max range of output
args.model_config.num_decoders = None               # number of decoders to use. [options: 0, 1, None]
args.model_config.freeze_encoder = False            # do not update encoder weights
args.model_config.freeze_decoder = False            # do not update decoder weights
args.model_config.multi_task_type = 'learned'       # find out loss multiplier by learning, choices=[None, 'learned', 'uncertainty', 'grad_norm', 'dwa_grad_norm']
args.model_config.target_input_ratio = 1            # Keep target size same as input size
args.model_config.input_nv12 = False                # convert input to nv12 format
args.model_config.enable_fp16 = False   
args.model = None                                   # the model itself can be given from ouside
args.model_name = 'fpn_aspp_regnetx800mf_edgeailite'# model architecture, overwritten if pretrained is specified
args.dataset_name = 'magna2022_segmentation' 

model_file = None 
model, changed_names = xvision.models.pixel2pixel.__dict__[args.model_name](args.model_config, model_file)
model = model.eval().cuda()

img = np.zeros((480,864,3), dtype=np.uint8) 

img_mean = 128.0
img_scale = 1.0/(0.25*256)

x = (img - img_mean) * img_scale
x = np.transpose(x, (2, 0, 1))
x = x[np.newaxis, ...]
x = torch.from_numpy(x).float().cuda()

y = model([x])