__version__ = '0.11.0a0+ed58577'
git_version = 'ed58577372edc9f886266a3ddf60aea094d742ab'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
