#################################################################################
# Copyright (c) 2018-2021, Texas Instruments Incorporated - http://www.ti.com
# All Rights Reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# * Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
# * Redistributions in binary form must reproduce the above copyright notice,
#   this list of conditions and the following disclaimer in the documentation
#   and/or other materials provided with the distribution.
#
# * Neither the name of the copyright holder nor the names of its
#   contributors may be used to endorse or promote products derived from
#   this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#################################################################################
# Also includes parts from: https://github.com/pytorch/vision
# License: License: https://github.com/pytorch/vision/blob/master/LICENSE

# BSD 3-Clause License
#
# Copyright (c) Soumith Chintala 2016,
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# * Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
# * Redistributions in binary form must reproduce the above copyright notice,
#   this list of conditions and the following disclaimer in the documentation
#   and/or other materials provided with the distribution.
#
# * Neither the name of the copyright holder nor the names of its
#   contributors may be used to endorse or promote products derived from
#   this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# ==============================================================================

# Some parts of the code are borrowed from: https://github.com/ansleliu/LightNet
# with the following license:
#
# MIT License
#
# Copyright (c) 2018 Huijun Liu
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""
Reference:

M. Cordts, M. Omran, S. Ramos, T. Rehfeld, M. Enzweiler, R. Benenson, U. Franke, S. Roth, and B. Schiele,
“The Cityscapes Dataset for Semantic Urban Scene Understanding,”
in Proc. of the IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 2016.
https://www.cityscapes-dataset.com/
"""


import os
import numpy as np
import cv2
import json
from torch.utils import data
import sys
import warnings
from tv.edgeailite import xnn

###########################################
# config settings
def get_config():
    dataset_config = xnn.utils.ConfigNode()
    dataset_config.image_folders = ('rgb_images',)
    dataset_config.input_offsets = None
    dataset_config.load_segmentation = True
    dataset_config.load_segmentation_five_class = False
    return dataset_config


###########################################
class Bdd100kBaseSegmentationLoader():
    """Bdd100kLoader: 
    Many Thanks to @fvisin for the loader repo: https://github.com/fvisin/dataset_loaders/blob/master/dataset_loaders/images/cityscapes.py"""

    colors = [[128, 64, 128], [244, 35, 232], [230 ,150, 140]]

    label_colours = dict(zip(range(3), colors))
    
    void_classes = []
    valid_classes = [0, 1, 2]

    # note: bicyclist and motorcyclist map to rider (train id: 21)
    class_names = ['drivable', 'alternatively drivable', 'background']

    ignore_index = 255
    class_map = {0:0, 1:1, 2:2}
    num_classes_ = 3

    class_weights_ = None
    # class_weights_ = np.array([0.0617,0.6778,170.5022,
    #                            0.3502,3.6956,4.3773,11.1057,262.8411,126.4007,
    #                            4.8936,37.8129,19.9896,14.9314,262.6892,293.1603,
    #                            0.1939,1.0000,1.0240,247.2846,
    #                            0.1543,
    #                            40.8879,3746.7285,
    #                            1.6883,10.2234,79.2800,1836.8116,1067.9310,286.0875], dtype=float)

    @classmethod
    def decode_segmap(cls, temp):
        r = temp.copy()
        g = temp.copy()
        b = temp.copy()
        for l in range(0, cls.num_classes_):
            r[temp == l] = cls.label_colours[l][0]
            g[temp == l] = cls.label_colours[l][1]
            b[temp == l] = cls.label_colours[l][2]

        rgb = np.zeros((temp.shape[0], temp.shape[1], 3))
        rgb[:, :, 0] = r / 255.0
        rgb[:, :, 1] = g / 255.0
        rgb[:, :, 2] = b / 255.0
        return rgb


    @classmethod
    def encode_segmap(cls, mask):
        # Put all void classes to zero
        for _voidc in cls.void_classes:
            mask[mask == _voidc] = cls.ignore_index
        for _validc in cls.valid_classes:
            mask[mask == _validc] = cls.class_map[_validc]
        return mask


    @classmethod
    def class_weights(cls):
        return cls.class_weights_



###########################################
class Bdd100kDataLoader(data.Dataset):
    def __init__(self, dataset_config, root, split="train", gt="labels/drivable", transforms=None, image_folders=('images/100k',),
                 search_images=False, load_segmentation=True, load_depth=False, load_motion=False, load_flow=False,
                 load_segmentation_five_class=False, inference=False, additional_info=False, input_offsets=None):
        super().__init__()
        if split not in ['train', 'val', 'test']:
            warnings.warn(f'unknown split specified: {split}')
        #
        self.root = root
        self.gt = gt
        self.split = split
        self.transforms = transforms
        self.image_folders = image_folders
        self.search_images = search_images
        self.files = {}

        self.additional_info = additional_info
        self.load_segmentation = load_segmentation
        self.load_segmentation_five_class = load_segmentation_five_class
        self.load_depth = load_depth
        self.load_motion = load_motion
        self.load_flow = load_flow
        self.inference = inference
        self.input_offsets = input_offsets

        self.image_suffix = '.jpg' 
        self.segmentation_suffix = '.png'

        self.image_base = os.path.join(self.root, image_folders[-1], self.split)
        self.segmentation_base = os.path.join(self.root, gt, 'masks', self.split)
                
        if self.search_images:        
            self.files = xnn.utils.recursive_glob(rootdir=self.image_base, suffix=self.image_suffix)
        else:            
            self.files = xnn.utils.recursive_glob(rootdir=self.segmentation_base, suffix=self.segmentation_suffix)        
        #
        self.files = sorted(self.files)
        
        if not self.files:
            raise Exception("> No files for split=[%s] found in %s" % (split, self.segmentation_base))
        #
        
        self.image_files = [None] * len(image_folders)
        for image_idx, image_folder in enumerate(image_folders):
            image_base = os.path.join(self.root, image_folder, self.split)
            self.image_files[image_idx] = sorted(xnn.utils.recursive_glob(rootdir=image_base, suffix='.jpg'))
            assert len(self.image_files[image_idx]) == len(self.image_files[0]), 'all folders should have same number of files'        
        
    def __len__(self):
        return len(self.files)


    def __getitem__(self, index):
        if self.search_images:
            image_path = self.files[index].rstrip()
            self.check_file_exists(image_path)
            segmentation_path = image_path.replace(self.image_base, self.segmentation_base).replace(self.image_suffix, self.segmentation_suffix)
        else:
            segmentation_path = self.files[index].rstrip()
            self.check_file_exists(segmentation_path)
            image_path = segmentation_path.replace(self.segmentation_base, self.image_base).replace(self.segmentation_suffix, self.image_suffix)
        #

        images = []
        images_path = []
        for image_idx, image_folder in enumerate(self.image_folders):
            sys.stdout.flush()
            this_image_path =  self.image_files[image_idx][index].rstrip()
            if image_idx == (len(self.image_folders)-1):
                assert this_image_path == image_path, 'image file name error'
            #
            self.check_file_exists(this_image_path)

            img = cv2.imread(this_image_path)[:,:,::-1]
            if self.input_offsets is not None:
                img = img - self.input_offsets[image_idx]
            #
            images.append(img)
            images_path.append(this_image_path)
        #

        targets = []
        targets_path = []

        if self.load_segmentation and (not self.inference):
            lbl = cv2.imread(segmentation_path,0)
            lbl = Bdd100kBaseSegmentationLoader.encode_segmap(np.array(lbl, dtype=np.uint8))
            targets.append(lbl)
            targets_path.append(segmentation_path)

        if (self.transforms is not None):
            images, targets = self.transforms(images, targets)            
        #

        if self.additional_info:
            return images, targets, images_path, targets_path
        else:
            return images, targets
    #


    def decode_segmap(self, lbl):
        if self.load_segmentation:
            return Bdd100kBaseSegmentationLoader.decode_segmap(lbl)
    #


    def check_file_exists(self, file_name):
        if not os.path.exists(file_name) or not os.path.isfile(file_name):
            raise Exception("{} is not a file, can not open with imread.".format(file_name))
    #

    def num_classes(self):
        nc = []
        if self.load_segmentation:
            nc.append(Bdd100kBaseSegmentationLoader.num_classes_)
        #
        return nc
    #


    def class_weights(self):
        cw = []
        if self.load_flow:
            cw.append(None)
        if self.load_depth:
            cw.append(None)
        if self.load_segmentation:
            cw.append(Bdd100kBaseSegmentationLoader.class_weights())
        return cw
    #


    def create_palette(self):
        palette = []
        if self.load_segmentation:
            palette.append(Bdd100kBaseSegmentationLoader.colors)
        return palette


##########################################
def bdd100k_drivable_segmentation_train(dataset_config, root, split=None, transforms=None):
    dataset_config = get_config().merge_from(dataset_config)
    gt = "labels/drivable"
    transform = transforms[0] if isinstance(transforms, (list,tuple)) else transforms
    train_split = Bdd100kDataLoader(dataset_config, root, 'train', gt, transforms=transform,
                                            load_segmentation=dataset_config.load_segmentation,
                                            load_segmentation_five_class=dataset_config.load_segmentation_five_class)
    return train_split


def bdd100k_drivable_segmentation(dataset_config, root, split=None, transforms=None, *args, **kwargs):
    dataset_config = get_config().merge_from(dataset_config)
    gt = "labels/drivable"
    train_split = val_split = None
    split = ['train', 'val']
    for split_name in split:
        if split_name == 'train':
            train_split = Bdd100kDataLoader(dataset_config, root, split_name, gt, transforms=transforms[0],
                                            load_segmentation=dataset_config.load_segmentation,
                                            load_segmentation_five_class=dataset_config.load_segmentation_five_class,
                                            *args, **kwargs)
        elif split_name == 'val':
            val_split = Bdd100kDataLoader(dataset_config, root, split_name, gt, transforms=transforms[1],
                                            load_segmentation=dataset_config.load_segmentation,
                                            load_segmentation_five_class=dataset_config.load_segmentation_five_class,
                                            *args, **kwargs)
        else:
            pass
    #
    return train_split, val_split


def bdd100k_segmentation_with_additional_info(dataset_config, root, split=None, transforms=None, *args, **kwargs):
    return bdd100k_drivable_segmentation(dataset_config, root, split=None, transforms=transforms, additional_info=True, *args, **kwargs)


#################################################################
# semantic inference
def bdd100k_drivable_segmentation_infer(dataset_config, root, split=None, transforms=None):
    dataset_config = get_config().merge_from(dataset_config)
    gt = "labels/drivable"
    split_name = 'val'
    infer_split = Bdd100kDataLoader(dataset_config, root, split_name, gt, transforms=transforms, image_folders=dataset_config.image_folders,
                                       load_segmentation=dataset_config.load_segmentation,
                                       load_segmentation_five_class=dataset_config.load_segmentation_five_class,
                                       search_images=True, inference=True, additional_info=True)
    return  infer_split


def bdd100k_drivable_segmentation_measure(dataset_config, root, split=None, transforms=None):
    dataset_config = get_config().merge_from(dataset_config)
    gt = "labels/drivable"
    split_name = 'val'
    infer_split = Bdd100kDataLoader(dataset_config, root, split_name, gt, transforms=transforms, image_folders=dataset_config.image_folders,
                                       load_segmentation=dataset_config.load_segmentation,
                                       load_segmentation_five_class=dataset_config.load_segmentation_five_class,
                                       search_images=True, inference=False, additional_info=True)
    return infer_split

def bdd100k_drivable_segmentation_infer_dir(dataset_config, root, split=None, transforms=None):
    dataset_config = get_config().merge_from(dataset_config)
    gt = "labels/drivable"
    split_name = 'val'
    infer_split = Bdd100kDataLoader(dataset_config, root, split_name, gt, transforms=transforms, image_folders=dataset_config.image_folders,
                                       load_segmentation=dataset_config.load_segmentation,
                                       load_segmentation_five_class=dataset_config.load_segmentation_five_class,
                                       search_images=True, inference=True, additional_info=True)
    return infer_split