python train_segmentation_main.py --model_name fpn_aspp_regnetx800mf_edgeailite \
--dataset_name bdd100k_drivable_segmentation \
--data_path /data/bdd100k \
--pretrained https://dl.fbaipublicfiles.com/pycls/dds_baselines/160906036/RegNetX-800MF_dds_8gpu.pyth \
--lr 1e-1 \
--batch_size 12 \
--img_resize 480 864 \
--output_size 720 1280 \
--workers 48 \
--enable_fp16 True

python train_segmentation_main.py --model_name fpn_aspp_regnetx800mf_edgeailite \
--dataset_name bdd100k_drivable_segmentation \
--data_path /data/bdd100k \
--resume data/checkpoints/edgeailite/bdd100k_drivable_segmentation/2022-09-01_14-30-59_bdd100k_drivable_segmentation_fpn_aspp_regnetx800mf_edgeailite_resize864x480_traincrop864x480/training/checkpoint.pth \
--lr 1e-1 \
--batch_size 12 \
--img_resize 480 864 \
--output_size 720 1280 \
--workers 48 \
--enable_fp16 True

python train_segmentation_main.py --model_name fpn_aspp_regnetx800mf_edgeailite \
--dataset_name bdd100k_drivable_segmentation \
--data_path /data/bdd100k \
--resume data/checkpoints/edgeailite/bdd100k_drivable_segmentation/2022-09-01_22-10-28_bdd100k_drivable_segmentation_fpn_aspp_regnetx800mf_edgeailite_resize864x480_traincrop864x480/training/checkpoint.pth \
--lr 1e-1 \
--batch_size 12 \
--img_resize 480 864 \
--output_size 720 1280 \
--workers 48 \
--enable_fp16 True \
--rand_h_flip False