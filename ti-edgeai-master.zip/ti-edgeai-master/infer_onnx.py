import tensorrt as trt
import os
import onnx
import torch
import common

# TRT_LOGGER = trt.Logger(trt.Logger.WARNING)

# builder = trt.Builder(TRT_LOGGER)
# network = builder.create_network(common.EXPLICIT_BATCH)
# config = builder.create_builder_config()
# parser = trt.OnnxParser(network, TRT_LOGGER)
# config.max_workspace_size = common.GiB(1)

# model_file = 'renetx800mf_edgeailite.onnx'
# with open(model_file, "rb") as model:
#     if not parser.parse(model.read()):
#         print("ERROR: Failed to parse the ONNX file.")
#         for error in range(parser.num_errors):
#             print(parser.get_error(error))
        
# engine = builder.build_engine(network, config)

# # model = onnx.load(model_file)
# # onnx.checker.check_model(model)

# from tv.edgeailite import xnn
# from tv.edgeailite import xvision

# args = xnn.utils.ConfigNode()
# args.model_config = xnn.utils.ConfigNode()
# args.model_config.output_type = ['segmentation']   # the network is used to predict flow or depth or sceneflow
# args.model_config.output_channels = [19]            # number of output channels
# args.model_config.prediction_channels = None        # intermediate number of channels before final output_channels
# args.model_config.input_channels = (3,)             # number of input channels
# args.model_config.final_upsample = True             # use final upsample to input resolution or not
# args.model_config.output_range = None               # max range of output
# args.model_config.num_decoders = None               # number of decoders to use. [options: 0, 1, None]
# args.model_config.freeze_encoder = False            # do not update encoder weights
# args.model_config.freeze_decoder = False            # do not update decoder weights
# args.model_config.multi_task_type = 'learned'       # find out loss multiplier by learning, choices=[None, 'learned', 'uncertainty', 'grad_norm', 'dwa_grad_norm']
# args.model_config.target_input_ratio = 1            # Keep target size same as input size
# args.model_config.input_nv12 = False                # convert input to nv12 format
# args.model_config.enable_fp16 = False   
# args.model = None                                   # the model itself can be given from ouside
# args.model_name = 'fpn_aspp_regnetx800mf_edgeailite'# model architecture, overwritten if pretrained is specified
# args.dataset_name = 'cityscapes_segmentation' 

# model_file = 'data/checkpoints/edgeailite/cityscapes_segmentation/2022-08-16_09-02-12_cityscapes_segmentation_fpn_aspp_regnetx800mf_edgeailite_resize768x384_traincrop768x384/training/model_best.pth'
# model, changed_names = xvision.models.pixel2pixel.__dict__[args.model_name](args.model_config, model_file)
# model = model.cuda()
# model.eval()

# dummy_input = [torch.randn(1, 3, 384, 768, device="cuda")]
# input_names = [ "input_1" ]
# output_names = [ "output_1" ]

# torch.onnx.export(model, dummy_input, "cityscapes_segmentation_fpn_aspp_regnetx800mf_edgeailite_resize768x384.onnx", verbose=True, input_names=input_names, output_names=output_names)


import onnx

# Load the ONNX model
model = onnx.load("cityscapes_segmentation_fpn_aspp_regnetx800mf_edgeailite_resize768x384.onnx")

# Check that the model is well formed
onnx.checker.check_model(model)

# Print a human readable representation of the graph
print(onnx.helper.printable_graph(model.graph))