import cv2
import os
import glob
import numpy as np
from tv.edgeailite import xnn
from tv.edgeailite import xvision
import torch 
from lib.utils.mask_utils_detectron2 import Visualizer

id_to_class_name_map = {0: 'drivable', 1:'alternatively drivable', 2:'background'}

def get_model_orig(model):
    is_parallel_model = isinstance(model, (torch.nn.DataParallel, torch.nn.parallel.DistributedDataParallel))
    model_orig = (model.module if is_parallel_model else model)
    model_orig = (model_orig.module if isinstance(model_orig, (xnn.quantize.QuantBaseModule)) else model_orig)
    return model_orig

class CCamera:
    def __init__(self, calib_path):

        # cylinder
        file_path = os.path.join(calib_path, 'LUT_Cylinder_ResReduction_2x_float.yml')
        fs = cv2.FileStorage(file_path, cv2.FILE_STORAGE_READ)
        lut_x = fs.getNode("LUT_X").mat() 
        lut_y = fs.getNode("LUT_Y").mat()
        self.map_cylinder = {}
        self.map_cylinder['lut_x'] = lut_x.reshape((540,960)).astype(np.float32)
        self.map_cylinder['lut_y'] = lut_y.reshape((540,960)).astype(np.float32)

        # linear
        file_path = os.path.join(calib_path, 'LUT_Undistort_ResReduction_2x_float.yml')
        fs = cv2.FileStorage(file_path, cv2.FILE_STORAGE_READ)
        lut_x = fs.getNode("LUT_X").mat() 
        lut_y = fs.getNode("LUT_Y").mat()
        self.map_linear = {}
        self.map_linear['lut_x'] = lut_x.reshape((540,960)).astype(np.float32)
        self.map_linear['lut_y'] = lut_y.reshape((540,960)).astype(np.float32)


    def undistort(self, src, undistorted_type = 'cylinder'):

        if undistorted_type == 'cylinder':
            lut_x = self.map_cylinder['lut_x']
            lut_y = self.map_cylinder['lut_y']
        else:
            lut_x = self.map_linear['lut_x']
            lut_y = self.map_linear['lut_y']
        
        return cv2.remap(src, lut_x, lut_y, cv2.INTER_LINEAR)


class CSemanticSeg:
    def __init__(self, model_path):
        args = xnn.utils.ConfigNode()
        args.model_config = xnn.utils.ConfigNode()
        args.model_config.output_type = ['segmentation']   # the network is used to predict flow or depth or sceneflow
        args.model_config.output_channels = [3]            # number of output channels
        args.model_config.prediction_channels = None        # intermediate number of channels before final output_channels
        args.model_config.input_channels = (3,)             # number of input channels
        args.model_config.final_upsample = True             # use final upsample to input resolution or not
        args.model_config.output_range = None               # max range of output
        args.model_config.num_decoders = None               # number of decoders to use. [options: 0, 1, None]
        args.model_config.freeze_encoder = False            # do not update encoder weights
        args.model_config.freeze_decoder = False            # do not update decoder weights
        args.model_config.multi_task_type = 'learned'       # find out loss multiplier by learning, choices=[None, 'learned', 'uncertainty', 'grad_norm', 'dwa_grad_norm']
        args.model_config.target_input_ratio = 1            # Keep target size same as input size
        args.model_config.input_nv12 = False                # convert input to nv12 format
        args.model_config.enable_fp16 = True   
        args.model = None                                   # the model itself can be given from ouside
        args.model_name = 'fpn_aspp_regnetx800mf_edgeailite'# model architecture, overwritten if pretrained is specified
        args.dataset_name = 'bdd100k_drivable_segmentation'
        args.pretrained = model_path
        args.quantize = False

        model_file = None 
        model, changed_names = xvision.models.pixel2pixel.__dict__[args.model_name](args.model_config, model_file)
        model = get_model_orig(model)        
        pretrained_data = torch.load(model_path)
        xnn.utils.load_weights(get_model_orig(model), pretrained=pretrained_data)        
        print('model loaded')
        self.model = model.cuda().eval()

        self.img_mean = np.array([128.0], dtype=np.float32)
        self.img_scale = np.array([1.0/(0.25*256)], dtype=np.float32) 

    def run(self, img):
        img = img[:,:,::-1]
        x = (img - self.img_mean) * self.img_scale

        if x.shape[0] != 480:
            x = cv2.resize(x, (864,480), interpolation=cv2.INTER_LINEAR)
        
        x = np.transpose(x, (2, 0, 1))
        x = x[np.newaxis, ...]
        x = torch.from_numpy(x).float().cuda()
        
        with torch.no_grad():
            y = self.model([x])
        
        y = torch.squeeze(y[0])
        y = y.cpu().numpy()
        
        return y

    def overlay(self, rgb_img, label_img):
        if rgb_img.shape[0] != 480:
            rgb_img = cv2.resize(rgb_img, (864,480)) 

        metadata = None
        frame_visualizer = Visualizer(rgb_img, metadata)
        output_img = frame_visualizer.overlay_instances(
            label_map=label_img, id_to_class_name_map=id_to_class_name_map
        )

        return cv2.cvtColor(output_img, cv2.COLOR_RGB2BGR)


# img_path = '/data/bdd100k/images/100k/val'
# img_path = '/mnt/NAS/2022-06-15-22-52-28'
img_path = '/mnt/pilot_logging_data/pilot_1/streaming/20220901/image_log_ffc/220901_094811'
calib_path = '/home/chulhoon/workspace/mros/src/sensors/camera/resources/calibration/Pilot1'
model_path = 'data/checkpoints/edgeailite/bdd100k_drivable_segmentation/2022-09-01_22-10-28_bdd100k_drivable_segmentation_fpn_aspp_regnetx800mf_edgeailite_resize864x480_traincrop864x480/training/checkpoint.pth'

model = CSemanticSeg(model_path)
camera_f = CCamera(os.path.join(calib_path, 'SVCE1_Front'))

img_list = []

for f in glob.glob(img_path + '/*.jpg'):
    # if '_2_' in f:
    #     img_list.append(f)
    img_list.append(f)

img_list.sort()

# _fourcc = cv2.VideoWriter_fourcc(*'MP4V')
# videorecorder1 = cv2.VideoWriter("img.mp4", _fourcc, 10, (1920,1080))
#videorecorder2 = cv2.VideoWriter("seg_linear.mp4", _fourcc, 10, (1728,960))

i = 0
while True:
    f = img_list[i]
    img = cv2.imread(f)
    
    # img_u = camera_f.undistort(img, 'linear')
    img_resized = cv2.resize(img, (864,480))

    seg = model.run(img)
    ove = model.overlay(img_resized, seg)
    
    img_disp = np.vstack((img_resized, cv2.cvtColor(ove, cv2.COLOR_RGB2BGR)))

    #videorecorder1.write(img_disp)
    #videorecorder2.write(img_out)

    cv2.namedWindow('disp',0)    
    cv2.imshow('disp', img_disp)    
    k = cv2.waitKey()

    if 27 == k:
        break
    elif ord('9') == k:
        i += 100
    elif ord('7') == k:
        i -= 100
    elif ord('6') == k:
        i += 10
    elif ord('4') == k:
        i -= 10
    elif ord('3') == k:
        i += 1
    elif ord('1') == k:
        i -= 1
    else:
        i += 1

    if i < 0:
        i = 0
    elif i >= len(img_list):
        break

#videorecorder1.release()
#videorecorder2.release()

cv2.destroyAllWindows()